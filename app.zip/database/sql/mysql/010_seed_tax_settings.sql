-- Seeds de tax_settings (MySQL)
INSERT IGNORE INTO tax_settings(name,type,value,currency) VALUES ('Serviço','flat',10,'BRL');
INSERT IGNORE INTO tax_settings(name,type,value,currency) VALUES ('Manuseio','percent',5,'BRL');
INSERT IGNORE INTO tax_settings(name,type,value,currency) VALUES ('Peso','weight',2,'BRL');
INSERT IGNORE INTO tax_settings(name,type,value,currency) VALUES ('Service','flat',5,'USD');
