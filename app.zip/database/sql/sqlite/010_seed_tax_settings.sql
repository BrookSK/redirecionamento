-- Seeds de tax_settings (SQLite)
INSERT OR IGNORE INTO tax_settings(name,type,value,currency) VALUES ('Serviço','flat',10,'BRL');
INSERT OR IGNORE INTO tax_settings(name,type,value,currency) VALUES ('Manuseio','percent',5,'BRL');
INSERT OR IGNORE INTO tax_settings(name,type,value,currency) VALUES ('Peso','weight',2,'BRL');
INSERT OR IGNORE INTO tax_settings(name,type,value,currency) VALUES ('Service','flat',5,'USD');
