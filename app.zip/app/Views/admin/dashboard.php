<section>
  <h1>Dashboard Admin</h1>
  <div class="grid-3">
    <div class="card stat"><div class="stat-value"><?= (int)$pending ?></div><div class="stat-label">Pacotes Pendentes</div></div>
    <div class="card stat"><div class="stat-value"><?= (int)$recentOrders ?></div><div class="stat-label">Pedidos</div></div>
    <div class="card stat"><div class="stat-value"><?= (int)$newUsers ?></div><div class="stat-label">Usuários</div></div>
  </div>
</section>
